FIGURE PACK - Surviving the Future
==============================================

Eleven figures from the book, 300 dpi PNG, with the caption and source line
for each. Sized for slides, reports and teaching material.

WHAT YOU MAY DO
  Use these figures in your own presentations, lectures, reports and
  publications. No permission needed, no fee, no attribution required --
  though citing the book is good practice and helps the argument travel.

WHAT YOU MAY NOT DO
  Resell the figures, or redistribute the pack itself as a standalone product.

Each figure in the book carries its own source line. Reproduce that line when
you use the figure, because the data belongs to the original source, not to
this book. The footnote below each figure tells you where the numbers came from.

INDEX
------------------------------------------------------------

  fig2_1.png
    Figure 2.1 Warming in 2050 and 2100 under three emission trajectories
    Source: Table 2.1. Bars show the 2100 range; SSP scenarios as summarised in IPCC (2021, 2023).

  fig4_1.png
    Figure 4.1 Days above 35 °C now and in 2050 in six cities
    Source: Table 4.1; SSP2-4.5 for the 2050 column.

  fig5_1.png
    Figure 5.1 People depending on six stressed basins, and the supply gap they face in 2050
    Source: Table 5.1; gap is the shortfall against projected demand under SSP2-4.5.

  fig6_1.png
    Figure 6.1 People exposed to a 1-in-100-year coastal flood in six cities
    Source: Table 6.1; exposure counts include subsidence where reported.

  fig7_1.png
    Figure 7.1 Yield change per additional degree of warming, by crop
    Source: Table 7.1. Bars for coffee and livestock show the reported range.

  fig8_1.png
    Figure 8.1 Decline at 2 °C and at 3 °C for four systems with measurable thresholds
    Source: Table 8.1. Coral value at 3 °C is the reported “greater than 99 per cent”.

  fig10_1.png
    Figure 10.1 Global GDP loss by 2050 under three emission paths
    Source: Table 10.1; loss is measured against a no-climate baseline.

  fig11_1.png
    Figure 11.1 Internal climate migrants by 2050, by region of origin
    Source: Table 11.1; estimates are internal movements, not cross-border refugees.

  fig17_1.png
    Figure 17.1 Annual excess heat deaths in 2050 under three adaptation paths
    Source: Table 17.1.

  fig22_1.png
    Figure 22.1 Deaths in eight urban and wildfire disasters, on a logarithmic scale
    Source: Table 22.1. Lytton shows deaths for British Columbia in 2021.

  fig23_1.png
    Figure 23.1 Deaths in four drought and famine crises, on a logarithmic scale
    Source: Table 23.1. Syria 2006–10 is omitted because the table records displacement, not deaths.
