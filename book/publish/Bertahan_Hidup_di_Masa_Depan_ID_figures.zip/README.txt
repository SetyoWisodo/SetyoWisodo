PAKET GAMBAR - Bertahan Hidup di Masa Depan
==============================================

Sebelas gambar dari buku, PNG 300 dpi, lengkap dengan keterangan dan baris
sumbernya. Ukurannya siap untuk slide, laporan, dan bahan ajar.

YANG BOLEH ANDA LAKUKAN
  Memakai gambar ini di presentasi, kuliah, laporan, dan publikasi Anda
  sendiri. Tanpa izin, tanpa biaya, tanpa wajib menyebutkan sumber --
  meski mengutip bukunya adalah kebiasaan baik dan membantu argumennya
  menyebar.

YANG TIDAK BOLEH
  Menjual kembali gambarnya, atau menyebarkan paket ini sebagai produk
  tersendiri.

Setiap gambar membawa baris sumbernya sendiri. Sertakan baris itu saat Anda
memakainya, karena datanya milik sumber aslinya, bukan milik buku ini.

DAFTAR GAMBAR
------------------------------------------------------------

  fig2_1_id.png
    Gambar 2.1 Pemanasan 2050 dan 2100 pada tiga lintasan emisi
    Sumber: Tabel 2.1. Garis tegak menunjukkan rentang 2100; skenario SSP sebagaimana dirangkum IPCC (2021, 2023).

  fig4_1_id.png
    Gambar 4.1 Hari di atas 35 °C sekarang dan pada 2050 di enam kota
    Sumber: Tabel 4.1; SSP2-4.5 untuk kolom 2050.

  fig5_1_id.png
    Gambar 5.1 Penduduk yang bergantung pada enam cekungan tertekan, dan kesenjangan pasokan pada 2050
    Sumber: Tabel 5.1; kesenjangan adalah kekurangan terhadap permintaan terproyeksi pada SSP2-4.5.

  fig6_1_id.png
    Gambar 6.1 Penduduk yang terpapar banjir pesisir periode ulang 100 tahun di enam kota
    Sumber: Tabel 6.1; jumlah terpapar mencakup penurunan tanah bila dilaporkan.

  fig7_1_id.png
    Gambar 7.1 Perubahan hasil panen per tambahan satu derajat pemanasan, menurut tanaman
    Sumber: Tabel 7.1. Batang untuk kopi dan ternak menunjukkan rentang yang dilaporkan.

  fig8_1_id.png
    Gambar 8.1 Penurunan pada 2 °C dan 3 °C untuk empat sistem dengan ambang terukur
    Sumber: Tabel 8.1. Nilai terumbu pada 3 °C adalah “lebih dari 99 persen” yang dilaporkan.

  fig10_1_id.png
    Gambar 10.1 Kerugian PDB global hingga 2050 pada tiga jalur emisi
    Sumber: Tabel 10.1; kerugian diukur terhadap garis dasar tanpa perubahan iklim.

  fig11_1_id.png
    Gambar 11.1 Migran iklim internal pada 2050, menurut kawasan asal
    Sumber: Tabel 11.1; estimasi adalah perpindahan internal, bukan pengungsi lintas batas.

  fig17_1_id.png
    Gambar 17.1 Kematian berlebih akibat panas per tahun pada 2050 di bawah tiga jalur adaptasi
    Sumber: Tabel 17.1.

  fig22_1_id.png
    Gambar 22.1 Kematian pada delapan bencana perkotaan dan kebakaran, pada skala logaritma
    Sumber: Tabel 22.1. Lytton menunjukkan kematian di British Columbia pada 2021.

  fig23_1_id.png
    Gambar 23.1 Kematian pada empat krisis kekeringan dan kelaparan, pada skala logaritma
    Sumber: Tabel 23.1. Suriah 2006–10 tidak dimasukkan karena tabel mencatat perpindahan, bukan kematian.
